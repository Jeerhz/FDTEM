# Partie 1 — Isoler la longueur du texte

Projet Overleaf autonome. Fichier principal : `partie1_longueur.tex`.

    partie1_longueur.tex          le rapport
    references.bib                la bibliographie (partagee avec le reste du rapport)
    figures/isolation/*.pdf       les 7 figures
    figures/make_isolation_figures.py   le script qui les produit

Compilateur : pdfLaTeX + BibTeX.
En local : pdflatex -> bibtex -> pdflatex -> pdflatex.
Sur Overleaf, la chaine est automatique.

Les figures sont deja incluses en PDF ; le script n'est la que pour tracer
leur origine. Il se relance depuis la racine du depot FDTEM :

    python report/figures/make_isolation_figures.py

et lit results/block_duel/block_duel.json et results/comet_align/comet_align.json.

Typographie francaise : la ligne `\usepackage[french]{babel}` est commentee dans
le preambule. Overleaf fournit babel-french, donc elle peut etre decommentee
pour obtenir les espaces insecables automatiques avant : ; ! ? et les guillemets.
